Audio Reactive Visualizer (PWA)
==================================

So verwendest du das Projekt (Smartphone-freundlich):

1) Entpacken und in einen Webspace oder Editor wie StackBlitz/Glitch/GitHub Pages laden.
2) Auf dem Handy öffnen und "Zum Homescreen hinzufügen" (PWA).
3) "Start" tippen, dann entweder:
   - Datei-Upload: Musikdatei wählen (looped), oder
   - Mic: Live-Audio über Mikro/Line-In.
4) Preset wählen (Mandala/Partikel/Waves), Sensitivity anpassen.
5) Für Bühne: Smartphone per HDMI-Adapter an Monitor/Beamer, Fullscreen.

Hinweise:
- iOS verlangt Nutzerinteraktion, daher zuerst "Start".
- Wake Lock hält den Bildschirm an; auf manchen Geräten nicht verfügbar.
- Performance: PixelDensity=1; reduziere Partikel/Segmente bei Bedarf.
